### Metric-Imperial Converter
  - Convert gal-l, kg-lbs, mi-km and vice versa
  - 16 Unit Test Cases for valid and invalid input using chai
  - 5 Functional test cases using chai-http 

### Exercise 
Instructions for building your project can be found at https://www.freecodecamp.org/learn/quality-assurance/quality-assurance-projects/metric-imperial-converter
