# Stock Price Checker

### Instructions
https://freecodecamp.org/learn/information-security/information-security-projects/stock-price-checker

### Functional Test Cases
- Viewing one stock: GET request to /api/stock-prices/
- Viewing one stock and liking it: GET request to /api/stock-prices/
- Viewing the same stock and liking it again: GET request to /api/stock-prices/
- Viewing two stocks: GET request to /api/stock-prices/
- Viewing two stocks and liking them: GET request to /api/stock-prices/