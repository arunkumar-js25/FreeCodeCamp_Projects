module.exports = {
  'mrs.': 'mrs',
  'mr.': 'mr',
  'ms.': 'ms',
  'mx.': 'mx',
  'dr.': 'dr',
  'prof.': 'prof'
}
