# FCC: Drum Machine

A Pen created on CodePen.io. Original URL: [https://codepen.io/freeCodeCamp/pen/MJyNMd](https://codepen.io/freeCodeCamp/pen/MJyNMd).

