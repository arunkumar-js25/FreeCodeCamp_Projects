# FCC: Javascript Calculator (backup)

A Pen created on CodePen.io. Original URL: [https://codepen.io/freeCodeCamp/pen/xXPeBe](https://codepen.io/freeCodeCamp/pen/xXPeBe).

