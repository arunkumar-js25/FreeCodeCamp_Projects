var dataUrl = "https://raw.githubusercontent.com/FreeCodeCamp/ProjectReferenceData/master/cyclist-data.json";

const w = 800;
const h = 400;

//Add Title
const title = d3.select("#main").append("h1").attr("id","title").text("Doping Scatterplot");

//Add SVG section
const svg = d3.select("#main")
                  .append('svg')
                  .attr("width", w+100)
                  .attr("height", h+100);

//X-Axis
const xScale = d3.scaleLinear().range([0,w]);
const xAxis = d3.axisBottom(xScale).tickFormat(d3.format("d"));
const xAxisBar = svg.append("g")
  .attr("transform","translate(60,400)")
  .attr("id","x-axis")
  .call(xAxis);

//Y-Axis
const yScale = d3.scaleLinear().range([h,0]);
const yAxis = d3.axisLeft(yScale).tickFormat(d3.format("d"));
const yAxisBar = svg.append("g")
  .attr("transform","translate(60,0)")
  .attr("id","y-axis")
  .call(yAxis);

d3.json(dataUrl,function(data) { 
  
});