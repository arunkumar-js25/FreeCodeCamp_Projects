# FCC : Random Quote Machine

A Pen created on CodePen.io. Original URL: [https://codepen.io/freeCodeCamp/pen/qRZeGZ](https://codepen.io/freeCodeCamp/pen/qRZeGZ).

Show random quotes using "Random Famous Quotes" API
(https://www.mashape.com/andruxnet/random-famous-quotes)

Forked from [Gabriel Nunes](http://codepen.io/hezag/)'s Pen [Random Quote Machine](http://codepen.io/hezag/pen/ZGxOLX/).

Forked from [Free Code Camp](http://codepen.io/FreeCodeCamp/)'s Pen [Random Quote Machine](http://codepen.io/FreeCodeCamp/pen/bELoPJ/).