# SHA-1 Password Cracker

### Instructions
https://www.freecodecamp.org/learn/information-security/information-security-projects/sha-1-password-cracker

### Logic
Create a function that takes in a SHA-1 hash of a password and returns the password if it is one of the top 10,000 passwords used. If the SHA-1 hash is NOT of a password in the database, return "PASSWORD NOT IN DATABASE"