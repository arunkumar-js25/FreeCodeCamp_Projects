var dataUrl = "https://raw.githubusercontent.com/FreeCodeCamp/ProjectReferenceData/master/cyclist-data.json";

const w = 800;
const h = 400;

//Add Title
const title = d3.select("#main").append("h1").attr("id","title").text("Doping Scatterplot");

//Add toolTip
var div = d3
  .select('body')
  .append('div')
  .attr('class', 'tooltip')
  .attr('id', 'tooltip')
  .style('opacity', 0);

//Add SVG section
const svg = d3.select("#main")
                  .append('svg')
                  .attr("width", w+200)
                  .attr("height", h+100);

//X-Axis
const xScale = d3.scaleLinear().range([100,w]);
const xAxis = d3.axisBottom(xScale).tickFormat(d3.format("d"));

//Y-Axis
var timeFormat = d3.timeFormat('%M:%S');
const yScale = d3.scaleTime().range([0,h]);
const yAxis = d3.axisLeft(yScale).tickFormat(timeFormat);


d3.json(dataUrl).then(function(data) { 
  data.forEach(function (d) {
      d.Place = +d.Place;
      var parsedTime = d.Time.split(':');
      d.Time = new Date(1970, 0, 1, 0, parsedTime[0], parsedTime[1]);
    });

   xScale.domain([
      d3.min(data, function (d) {
        return d.Year - 1;
      }),
      d3.max(data, function (d) {
        return d.Year + 1;
      })
    ]);
    yScale.domain(
      d3.extent(data, function (d) {
        return d.Time;
      })
    );
  
  const xAxisBar = svg.append('g').call(xAxis).attr('id','x-axis').attr("transform", "translate(0,"+h+")");
  const yAxisBar = svg.append('g').call(yAxis).attr('id','y-axis').attr("transform", "translate(100,0)");
  
  svg.append('text')
      .attr('transform', 'rotate(-90)')
      .attr('x', -160)
      .attr('y', 55)
      .style('font-size', 18)
      .text('Time in Minutes');
  
  svg.selectAll('.dot')
    .data(data)
    .enter()
    .append('circle')
    .attr('class', 'dot')
      .attr('r', 6)
      .attr('cx', function (d) {
        return xScale(d.Year);
      })
      .attr('cy', function (d) {
        return yScale(d.Time);
      })
      .attr('data-xvalue', function (d) {
        return d.Year;
      })
      .attr('data-yvalue', function (d) {
        return d.Time.toISOString();
      })
  .on('mouseover', function (event, d) {
        div.style('opacity', 0.9);
        div.attr('data-year', d.Year);
        div
          .html(
            d.Name +
              ': ' +
              d.Nationality +
              '<br/>' +
              'Year: ' +
              d.Year +
              ', Time: ' +
              timeFormat(d.Time) +
              (d.Doping ? '<br/><br/>' + d.Doping : '')
          )
          .style('left', event.pageX + 'px')
          .style('top', event.pageY - 28 + 'px'); 
      })
    .style('fill', function (d) {
        return d.Doping !== '' ? "red" : "blue";
      })
    .on('mouseout', function () {
        div.style('opacity', 0);
      });
  
  var legendContainer = svg.append('g').attr('id', 'legend')
    .append("text")
    .attr('x', w - 100)
    .attr('y', 20)
    .text("NOTE: Blue color is doping allegations");

}).catch(err => console.log(err));