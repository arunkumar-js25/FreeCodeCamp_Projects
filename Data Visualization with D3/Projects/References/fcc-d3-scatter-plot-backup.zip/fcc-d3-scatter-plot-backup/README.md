# FCC: D3 Scatter Plot (backup)

A Pen created on CodePen.io. Original URL: [https://codepen.io/freeCodeCamp/pen/LzOvvw](https://codepen.io/freeCodeCamp/pen/LzOvvw).

